// hw3.cpp - MPI matrix-vector multiplication
// Reads matrix size N from input.txt (rank 0) and performs distributed mat-vec.
// Output lines contain "Time =" and "Performance =" tokens consumed by performance_report.py.

#include <mpi.h>
#include <chrono>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>

using Matrix = float*;

static double microtime() {
    auto now = std::chrono::high_resolution_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
}

static double get_microtime_resolution() {
    return 1.0; // microseconds
}

static Matrix CreateMatrix(int rows, int cols) {
    size_t count = static_cast<size_t>(rows) * static_cast<size_t>(cols);
    Matrix M = nullptr;
    if (count > 0) {
        M = new (std::nothrow) float[count];
        if (!M) {
            std::cerr << "Matrix allocation failed for " << rows << "x" << cols << std::endl;
        }
    }
    return M;
}

static void FreeMatrix(Matrix M) {
    delete[] M;
}

static void InitVector(Matrix B, int len) {
    for (int i = 0; i < len; ++i) {
        B[i] = 1.0f / static_cast<float>(i + 2);
    }
}

static void InitLocalMatrix(Matrix A, int rows, int cols, int rowOffset) {
    for (int r = 0; r < rows; ++r) {
        int gRow = rowOffset + r;
        for (int c = 0; c < cols; ++c) {
            A[r * cols + c] = 1.0f / static_cast<float>(gRow + c + 2);
        }
    }
}

static void MatVecMultLocal(Matrix A, Matrix B, Matrix C, int rows, int cols) {
    std::memset(C, 0, sizeof(float) * static_cast<size_t>(rows));
    for (int r = 0; r < rows; ++r) {
        const float* row = &A[r * cols];
        float sum = 0.0f;
        int k = 0;
        int limit = cols - (cols % 4);
        for (; k < limit; k += 4) {
            sum += row[k] * B[k];
            sum += row[k + 1] * B[k + 1];
            sum += row[k + 2] * B[k + 2];
            sum += row[k + 3] * B[k + 3];
        }
        for (; k < cols; ++k) {
            sum += row[k] * B[k];
        }
        C[r] = sum;
    }
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank = 0, size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int N = 0;
    MPI_Datatype sizeType;
    MPI_Type_contiguous(1, MPI_INT, &sizeType);
    MPI_Type_commit(&sizeType);

    if (rank == 0) {
        std::ifstream fin("input.txt");
        if (!fin) {
            std::cerr << "Failed to open input.txt" << std::endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        fin >> N;
        if (!fin || N <= 0) {
            std::cerr << "Invalid matrix size in input.txt" << std::endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        for (int dest = 1; dest < size; ++dest) {
            MPI_Send(&N, 1, sizeType, dest, 0, MPI_COMM_WORLD);
        }
    } else {
        MPI_Recv(&N, 1, sizeType, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if (N <= 0) {
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    int rowsPerProc = N / size;
    int remainder = N % size;
    int localRows = rowsPerProc + (rank < remainder ? 1 : 0);
    int rowOffset = rank * rowsPerProc + std::min(rank, remainder);

    Matrix A_local = CreateMatrix(localRows, N);
    Matrix B = CreateMatrix(N, 1);
    Matrix C_local = CreateMatrix(localRows, 1);
    Matrix C_global = nullptr;
    if (rank == 0) {
        C_global = CreateMatrix(N, 1);
    }

    InitVector(B, N);
    InitLocalMatrix(A_local, localRows, N, rowOffset);

    MPI_Barrier(MPI_COMM_WORLD);
    double t1 = microtime();
    MatVecMultLocal(A_local, B, C_local, localRows, N);
    MPI_Barrier(MPI_COMM_WORLD);
    double t2 = microtime();

    std::vector<int> recvCounts;
    std::vector<int> displs;
    if (rank == 0) {
        recvCounts.resize(size);
        displs.resize(size);
        for (int r = 0; r < size; ++r) {
            int rows = rowsPerProc + (r < remainder ? 1 : 0);
            recvCounts[r] = rows;
            displs[r] = r * rowsPerProc + std::min(r, remainder);
        }
    }

    MPI_Gatherv(C_local, localRows, MPI_FLOAT,
                C_global, recvCounts.data(), displs.data(), MPI_FLOAT,
                0, MPI_COMM_WORLD);

    if (rank == 0) {
        double elapsed = t2 - t1; // microseconds
        std::cout << "\nTime = " << elapsed << " us\tTimer Resolution = "
                  << get_microtime_resolution() << " us\tPerformance = "
                  << 2.0 * N * N * 1e-3 / elapsed << " Gflop/s" << std::endl;
        if (C_global && N > 0) {
            std::cout << "C[N/2] = " << static_cast<double>(C_global[N / 2]) << "\n" << std::endl;
        }
    }

    FreeMatrix(A_local);
    FreeMatrix(B);
    FreeMatrix(C_local);
    FreeMatrix(C_global);

    MPI_Type_free(&sizeType);
    MPI_Finalize();
    return 0;
}
